module.exports = {
  Admin: "Admin",
  UserLog: "Userlog",
  AdminType: "Admintype",
  Privilege: "Privilege",
  Function: "Function",
};
