module.exports = {
    logActions: ["post", "put", "delete", "get"],
};